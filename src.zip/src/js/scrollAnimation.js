export function initScrollAnimation() {
    const sections = document.querySelectorAll('.problems, .approach, .cases, .testimonials');

    sections.forEach(section => {
        const container = section.querySelector('.container');
        const title = container.querySelector('.section-title');

        // Оборачиваем оригинал в static
        const staticWrapper = document.createElement('div');
        staticWrapper.className = 'section-header static';
        container.insertBefore(staticWrapper, title);
        staticWrapper.appendChild(title);

        // Создаём клон как фиксированный
        const fixedHeader = document.createElement('div');
        fixedHeader.className = 'section-header fixed';
        fixedHeader.appendChild(title.cloneNode(true));
        container.insertBefore(fixedHeader, staticWrapper);
    });


    function handleScroll() {
        const viewportHeight = window.innerHeight;

        sections.forEach(section => {
            const fixed = section.querySelector('.section-header.fixed');
            const stat = section.querySelector('.section-header.static');
            const sectionRect = section.getBoundingClientRect();
            const staticRect = stat.getBoundingClientRect();

            const appearStart = viewportHeight * 1.4;

            if (sectionRect.top <= appearStart && sectionRect.top > staticRect.top) {
                fixed.classList.add('visible');
                fixed.classList.remove('hidden');
                stat.classList.remove('visible');
            } else if (sectionRect.top <= staticRect.top) {
                fixed.classList.add('hidden');
                fixed.classList.remove('visible');
                stat.classList.add('visible');
            } else {
                fixed.classList.remove('visible', 'hidden');
                stat.classList.remove('visible');
            }
        });
    }

    window.addEventListener('scroll', () => requestAnimationFrame(handleScroll));
    window.addEventListener('resize', () => requestAnimationFrame(handleScroll));
    requestAnimationFrame(handleScroll);
}
