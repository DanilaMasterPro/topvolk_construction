import { casesData } from './casesData.js';
import { initNeuralBackground } from './neuralBackground.js';
import { initScrollAnimation } from './scrollAnimation.js';

document.addEventListener('DOMContentLoaded', () => {
    // Initialize neural background
    initNeuralBackground();
    initScrollAnimation();

    // Render cases first
    const casesContainer = document.querySelector('.cases-grid');
    casesContainer.innerHTML = casesData.map(caseData => renderCaseCard(caseData)).join('');

    // Then initialize sliders after content is rendered
    const sliders = document.querySelectorAll('.slider');
    sliders.forEach(slider => initializeSlider(slider));
});

function renderCaseCard(caseData) {
    return `
        <div class="case-card">
            <div class="case-header">
                <div class="case-title">
                    <h3>${caseData.title}</h3>
                    <p class="case-subtitle">${caseData.subtitle}</p>
                </div>
            </div>

            <div class="case-main">
                <div class="case-gallery-container">
                    <div class="case-gallery">
                        <div class="slider">
                            ${caseData.images.map(img => `<img src="${img}" alt="${caseData.title} view">`).join('')}
                        </div>
                        <div class="slider-nav"></div>
                        <div class="slider-arrows">
                            <button class="slider-arrow prev">←</button>
                            <button class="slider-arrow next">→</button>
                        </div>
                    </div>
                    <div class="case-gallery-results">
                        ${caseData.results.slice(0, -1).map(result => `<div class="result-item">${result}</div>`).join('')}
                    </div>
                </div>

                <div class="case-info">
                    <div class="case-details">
                        <h4>Цель проекта 🎯</h4>
                        <p>${caseData.goal}</p>
                        <br>
                        <h4>Решение:</h4>
                        <ol class="solution-steps">
                            ${caseData.steps.map(step => `<li>${step}</li>`).join('')}
                        </ol>

                        <div class="case-mobile-results">
                            ${caseData.results.map(result => `<div class="result-item">${result}</div>`).join('')}
                        </div>

                        <div class="case-links">
                            <a href="${caseData.links.demo}" target="_blank" class="case-btn">👁 Смотреть сайт</a>
                            <a href="${caseData.links.contact}" target="_blank" class="case-btn">📩 Хочу также</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function initializeSlider(slider) {
    const slides = slider.querySelectorAll('img');
    const sliderNav = slider.closest('.case-gallery').querySelector('.slider-nav');
    const prevBtn = slider.closest('.case-gallery').querySelector('.slider-arrow.prev');
    const nextBtn = slider.closest('.case-gallery').querySelector('.slider-arrow.next');
    
    let currentSlide = 0;
    
    // Create dots
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('slider-dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(index));
        sliderNav.appendChild(dot);
    });
    
    const dots = sliderNav.querySelectorAll('.slider-dot');
    
    function updateDots() {
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
    }
    
    function goToSlide(index) {
        currentSlide = index;
        slider.style.transform = `translateX(-${index * 100}%)`;
        updateDots();
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        goToSlide(currentSlide);
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        goToSlide(currentSlide);
    }
    
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
    
    // Optional: Auto-advance slides
    setInterval(nextSlide, 5000);
}

// Modal handling
const modal = document.getElementById('contactModal');
const btn = document.querySelector('.contact-btn');
const span = document.querySelector('.close-modal');
const form = document.getElementById('contactForm');

btn.addEventListener('click', () => {
    modal.style.display = 'block';
});

span.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// Form submission
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const contact = document.getElementById('contact').value;
    
    const BOT_TOKEN = '7808652944:AAHDqPPqu2_IbKpFg02rBjWwtDJN_aDomjs'; // Replace with your bot token
    const CHAT_ID = '612414314'; // Replace with your chat ID
    
    const message = `
🔥 Новая заявка!

👤 Имя: ${name}
📱 Контакт: ${contact}
    `;
    
    try {
        const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                chat_id: CHAT_ID,
                text: message,
                parse_mode: 'HTML'
            })
        });

        if (response.ok) {
            alert('Спасибо! Я свяжусь с вами в ближайшее время.');
            form.reset();
            modal.style.display = 'none';
        } else {
            throw new Error('Ошибка отправки');
        }
    } catch (error) {
        alert('Произошла ошибка. Пожалуйста, попробуйте позже.');
    }
});

// Инициализация слайдера отзывов
const testimonialsSwiper = new Swiper('.testimonials-slider .swiper', {
    slidesPerView: 'auto',
    spaceBetween: 30,
    centeredSlides: true,
    loop: true,

    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    breakpoints: {
        768: {
            centeredSlides: false,
            slidesPerView: 3,
        },
        1024: {
            centeredSlides: false,
            slidesPerView: 4,
        }
    }
});